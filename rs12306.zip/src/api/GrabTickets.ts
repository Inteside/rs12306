// 抢票相关接口
import request from '../utils/request';

// 获取票价
export const fetchTicketPrice = (train_date: string, from_station: string, to_station: string) =>
    request.get(`/otn/leftTicketPrice/query?leftTicketDTO.train_date=${train_date}&leftTicketDTO.from_station=${from_station}&leftTicketDTO.to_station=${to_station}&leftTicketDTO.ticket_type=1`);
